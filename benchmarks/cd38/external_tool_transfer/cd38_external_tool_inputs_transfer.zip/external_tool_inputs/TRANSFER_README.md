# CD38 External Tool Transfer Package

This zip contains the CD38 PDB inputs and command templates needed to run external P2Rank/fpocket tools.

## Windows PowerShell

1. Unzip this archive and enter `external_tool_inputs`.
2. Prefer `run_cd38_external_next_benchmark.ps1`; it runs only the missing benchmark actions from the current action plan.
3. If you intentionally want all template rows, run `run_p2rank_templates.ps1` and `run_fpocket_templates.ps1`.

## Linux / WSL

1. Unzip this archive and enter `external_tool_inputs`.
2. Prefer `chmod +x run_cd38_external_next_benchmark.sh` and `./run_cd38_external_next_benchmark.sh`; it runs only the missing benchmark actions from the current action plan.
3. If you intentionally want all template rows, run `./run_p2rank_templates.sh` and `./run_fpocket_templates.sh`.

## Copy Back

Preflight resolves package-local paths first, so the unzipped folder can be moved between machines without relying on absolute paths from the original project.

After external tools finish, either copy these generated folders back into the original project package directory:

- `p2rank_outputs/`
- `fpocket_runs/*/*_out/`

Use `cd38_external_tool_return_checklist.md` or `cd38_external_tool_expected_returns.csv` to confirm which PDB/method outputs are expected before zipping the returned folder.

Or zip this whole returned folder and import it in the original project with:

```bash
python import_cd38_external_tool_outputs.py --source returned_external_tool_inputs.zip
```

The importer also handles one extra wrapper folder around `p2rank_outputs/` or `fpocket_runs/`, writes scan and coverage CSVs, and reports a source diagnosis such as `input_package_without_external_outputs`.

Or let finalize import the returned package before checking readiness:

```bash
python finalize_cd38_external_benchmark.py --import_source returned_external_tool_inputs.zip --run_discovered
```

If you imported outputs separately, then finalize:

```bash
python finalize_cd38_external_benchmark.py --run_discovered
```
